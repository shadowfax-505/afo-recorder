
## SD command correction — 2026-09-27

Breadboard recording profiles were rebuilt with GPIO47 CMD; PCB profiles retain GPIO38. Native pin/metadata checks and browser endpoint, zoom and stage checks passed. Host regression tests passed. CAD/manufacturing files are unchanged by this firmware-only fixture correction. No physical SD performance was measured. See sd-card-wiring.md and firmware-build-guide.md.
