> MPU variant: [mpu6050-wiring-and-timing.md](mpu6050-wiring-and-timing.md) is authoritative for sensor wiring, timing and current release gates. Inherited ADC/analog instructions remain applicable.

# Breadboard assembly workbench

The main viewer now focuses on one analog breadboard at a time. Use **PCB / system overview** to open the preserved overview model. The overview is not an insertion guide.

## What is specified

- 2.54 mm hole spacing within each five-hole strip and between rows; 7.62 mm from column e to f. Use a breadboard with this geometry and at least 33 rows. Check its numbering and continuity before use; rotate or relabel the fixture to match the view.
- Each row connects a–e and separately f–j. No power rails or split-rail continuity is assumed.
- Select the build stage and board. BB0 is midpoint; BB1 onward are individual EMG analog paths. The expandable versions physically populate all four input paths even when firmware enables only two.
- Each component step lists every pin, insertion hole and electrical net. MCP6002 DIP pin 1 is e10; the notch faces row 9. Pin numbers go down the left and up the right. Use the named DIP part, not a visually similar IC with a different pinout.
- Jumper steps identify both exact holes. The selected lead pair is highlighted in 3D and on the readable top-down map. Click any hole for its strip, net and occupied neighbors. Show connected strips to visualize the internal metal contacts.
- Start with isolated steps to avoid a bundle of overlapping wires. All-jumper mode is an overview. Wire bends and heights are illustrative, not cut lengths or a collision-checked harness.
- Checkboxes are saved locally in this browser. They record manual assembly progress only and cannot establish correct wiring or a passed electrical test.
- Print the current board for a labeled hole map and complete assembly table. The same instructions are in `breadboard/assembly-steps.csv`.

## Physical limits still open

This is an insertion guide for the analog DIP/passive circuits, not a released pin-by-pin implementation of every module. DevKitC-1 N8R8 and Adafruit 4682 are selected; the IMU carrier SKU remains unspecified. ADS131M04 evaluation-board choice remains open. The RoboticsBD AD7606 photograph does not verify its header numbering, VIO straps or DOUT routing. BAV199 carrier physical headers are also unverified.

External leads are amber steps marked UNVERIFIED. The viewer shows only their known breadboard hole and logical destination. It deliberately does not draw a fictitious physical module socket, and these steps cannot be marked complete in the viewer. Obtain a board schematic or verified powered-off continuity map and update the model before installing those leads.

Component bodies are illustrative. Verify purchased resistor/capacitor dimensions and lead spacing; bend leads or use suitable non-polarized through-hole parts without changing the specified insertion holes. DIP geometry is nominal. This view does not establish mechanical clearance for every purchased component.

The lab fixture uses regulated rails and module circuits with documented differences from the final PCB. The controller, power converters, USB interlock and remote module pin maps require their own implementation verification. Selecting stages 2, 3 and 6–10 shows the status of those requirements rather than inventing breadboard placements.

## Verification

`python3 design/build_assembly.py` regenerates the viewer contract and checks each occupied hole against the specification and breadboard layout. It checks duplicate occupancy, conflicting nets on a strip and disconnected instances of a local net. Results are in `breadboard/assembly-checks.json`. These are software connectivity checks, not measured continuity or hardware validation.

Work unpowered during assembly. Use synthetic signals for instrument-connected tests, with no person attached. Follow staged-build-guide.md numerical acceptance gates after each block is assembled. No new PCB or firmware changes are made by this viewer update.

## Whole setup view

The viewer opens at stage 10 in Whole setup mode, showing every analog breadboard and illustrative system module together. Click a breadboard or choose one in Focus board to enter its insertion guide. Return using the View selector. Stage selection filters the whole setup. Dashed inter-module links represent functional connectivity, not physical header pin assignments; Wi-Fi is wireless.

## Exact wire selection — viewer v5

Whole setup now has an **Exact wire endpoints** selector and **Enlarge wire** control. Solid wires cover the analog-board jumpers, explicitly allocated shared-rail links between breadboards, and ESP32-to-SD clock, DAT0 and ground. Select a wire to label both endpoints and dim the others. Source tables are in `breadboard/exact-wire-endpoints.csv`; shared-rail endpoint allocation is in `breadboard/physical-harness.json`. Existing generator output is overlaid with that file at load time. Hole-net equality and unique harness endpoint use are checked.

SD endpoints use the manufacturer's Eagle JP1 contactrefs and coordinates; ESP endpoints use Espressif J3 header numbering. Orient the model with the antenna at the top and the USB ports at the bottom. SD header numbering is from Eagle, not an inferred seller pin list. The reconstructed ESP component positions remain approximate.

The viewer now includes four SD connections: CLK, CMD, D0 and ground. CMD connects ESP J3.17/GPIO47 to SD JP1.5/DI. SD power delivery remains conditional on the verified 3.3 V rail; see sd-card-wiring.md. ADC, IMU, MyoWare, protection-carrier and regulator physical pin maps remain incomplete. Dashed conceptual links are now off by default. Do not treat this subset as a complete working harness.

References: https://docs.espressif.com/projects/esp-dev-kits/en/latest/esp32s3/esp32-s3-devkitc-1/user_guide_v1.1.html and https://github.com/adafruit/Adafruit-MicroSD-SPI-or-SDIO-card-breakout-PCB .

## Whole-system connections

See [system wiring](system-wiring.md) and [connection CSV](../breadboard/system-wiring.csv) for every external subsystem connection. All named-terminal wires are visible by default in the updated viewer. Dashed lines and amber terminal panels remain unverified physical endpoints; follow the listed evidence requirements before assembly. The earlier exact-wire CSV still contains the verified jumper and SD subset.
