# MPU-6050 validation report

## Completed software and design checks

- 10 ESP-IDF firmware profiles cross-compiled: recording, SD-only breadboard recording, controller/ADC diagnostics and independent one-/two-IMU diagnostics. Each build manifest identifies its channels, hardware role, Wi-Fi setting and MPU6050 sensor. No binary has been flashed or bench-tested here.
- 43 host tests passed, including legacy ICM conversion, MPU byte order/scaling, sensor identity, batch validation, missing samples, uncertain timing, overflow status, interrupted files and live reception.
- Native tests exercise the same FIFO sizing/overflow and timing-estimation helpers compiled into firmware. Source: `host/tests/mpu_timing_native.c`; compile with `-Ifirmware/main`.
- Synthetic clean, missing-sample, IRQ-gap, overflow and truncated-file recordings were converted for each supported EMG channel count. Clean fixtures pass structural/signal checks; faults produce failed quality checks or explicit gaps. Plots and quality reports are under `examples/mpu6050`.
- Schematic/PCB/firmware/viewer consistency: PASS, see `consistency.json`. ERC: zero violations. DRC: zero violations and zero unconnected items. Manufacturing files and STEP/GLB exports were regenerated from this variant's KiCad files.
- Browser checks: stage selection, full setup, module inspection/zoom, wire selection/zoom, single-board focus and compact PCB view loaded across all three MPU variants without captured JavaScript errors. Physical module endpoint positions remain unverified.
- Original ICM package file hashes verified unchanged. See `original-package-preservation.json`.

## Pending physical tests and release gates

The GY-521 regulator and pull-up connections, physical header order, chip supply, bus rise time, full-length cable reliability, interrupt latency, clock drift, filter delay, power/noise/crosstalk, sustained SD/Wi-Fi load and battery runtime remain unmeasured. AD7606 digital header mapping is still pending. Breadboard firmware now avoids the GPIO38 RGB LED by using GPIO47 for SD CMD; physical SD operation still needs testing. See `mpu6050-wiring-and-timing.md` for staged tests and acceptance targets.

ERC/DRC and compilation do not establish electrical safety, measurement accuracy or research readiness. No hardware order or human recording is authorized by this report. Older inherited reports/examples describe baseline or legacy compatibility; this report and the MPU-specific reports govern this derivative.

## SD command correction — 2026-09-27

Breadboard recording profiles were rebuilt with GPIO47 CMD; PCB profiles retain GPIO38. Native pin/metadata checks and browser endpoint, zoom and stage checks passed. Host regression tests passed. CAD/manufacturing files are unchanged by this firmware-only fixture correction. No physical SD performance was measured. See sd-card-wiring.md and firmware-build-guide.md.

## Photo header mapping — 2026-09-27

Supplied photographs establish the pictured AD7606 CN1 and/or GY-521 header label order. The viewer routes those endpoints to photo-ordered headers; source photos and orientation diagrams are included. Pin-map coverage, GPIO consistency and browser selection checks passed. Added AD7606 unused serial data-pin ground connections and STBY configuration check where applicable. Electrical continuity, serial-mode resistor configuration, rail levels and mechanical dimensions remain unmeasured. Firmware and manufacturing outputs are unchanged.
