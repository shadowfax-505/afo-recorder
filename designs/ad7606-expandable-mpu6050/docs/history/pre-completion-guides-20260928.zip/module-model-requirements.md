> MPU variant: [mpu6050-wiring-and-timing.md](mpu6050-wiring-and-timing.md) is authoritative for sensor wiring, timing and current release gates. Inherited ADC/analog instructions remain applicable.

# Module model status

See [selected lab parts](selected-lab-parts.md) and `module-model-evidence.json` for the current per-part evidence. Regulator and SD geometry now comes from manufacturer STEP; other models have explicit limitations. Physical harness release remains pending.
