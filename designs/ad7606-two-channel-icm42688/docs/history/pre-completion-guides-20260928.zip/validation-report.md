
## SD command correction — 2026-09-27

Breadboard recording profiles were rebuilt with GPIO47 CMD; PCB profiles retain GPIO38. Native pin/metadata checks and browser endpoint, zoom and stage checks passed. Host regression tests passed. CAD/manufacturing files are unchanged by this firmware-only fixture correction. No physical SD performance was measured. See sd-card-wiring.md and firmware-build-guide.md.

## Photo header mapping — 2026-09-27

Supplied photographs establish the pictured AD7606 CN1 and/or GY-521 header label order. The viewer routes those endpoints to photo-ordered headers; source photos and orientation diagrams are included. Pin-map coverage, GPIO consistency and browser selection checks passed. Added AD7606 unused serial data-pin ground connections and STBY configuration check where applicable. Electrical continuity, serial-mode resistor configuration, rail levels and mechanical dimensions remain unmeasured. Firmware and manufacturing outputs are unchanged.
