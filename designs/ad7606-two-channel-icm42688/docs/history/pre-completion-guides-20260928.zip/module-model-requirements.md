# Module model status

See [selected lab parts](selected-lab-parts.md) and `module-model-evidence.json` for the current per-part evidence. Regulator and SD geometry now comes from manufacturer STEP; other models have explicit limitations. Physical harness release remains pending.
