# Build one working stage at a time

Start with the [sequential development workbook](../development/index.html): it separates each addition, provides blank results sheets and states exactly what evidence to submit.

**This guide is only for AD7606 + two MyoWare RAW inputs + two ICM-42688-P carriers.** Use the [exact hole/contact tables](build-guide.html) beside the [interactive build view](../viewer/build.html). Power off before each addition. Record the result before continuing; an empty results cell means untested.

The numerical limits below are integration gates, not a calibration certificate or guaranteed performance. The filter envelope comes from `simulations/results/response.csv`; power, noise and timing still require measurements. Read the [current integrated verification](integrated-verification.html) and [historical diagnostic evidence](virtual-verification.html), then use the [applied simulation findings](breadboard-refinements.html), [probe contacts](../breadboard/probe-connections.csv) and [blank bench checklist](bench-checklist.csv) while completing the physical gates below. The [current breadboard lab kit](../breadboard/breadboard-lab-kit.zip) includes the six breadboard profiles; simulation-only firmware is excluded. Complete lab gates and final design review before ordering the compact PCB. Read the [laptop setup guide](laptop-setup.html) to try the example recording, check the download and install optional plotting dependencies.

| Step | Add only this | Instrument / check | Continue when | If it fails |
|---|---|---|---|---|
| 1 | Selected regulators and midpoint breadboard | DMM at rails; scope with short ground spring; current-limited supply and dummy loads | Digital rail 3.23–3.43 V; analog rail 2.94–3.06 V; ADC rail 4.80–5.20 V with startup never above 5.25 V; midpoint 0.49–0.51 × measured analog rail. Check 5 V at 30 mA load as well as idle | Disconnect loads; confirm regulator type, polarity, grounds and local capacitors. Do not increase current limit to hide a short |
| 2 | ESP32, controls and USB detection | Flash `diagnostic-controller`; view USB serial; DMM on GPIO21 | Repeat 20 programming/reset cycles; button and LEDs match output; GPIO21 LOW when USB attached and HIGH when absent (diagnostic attachment indicator prints 1/0); 3.3 V rail stays in range | Check common ground, pull-ups and Q2 orientation; use external sense-only USB wiring, not an unintended DevKit power path |
| 3a | AD7606 module, **without ESP32 signal leads** | Unpowered continuity plus DMM/scope on VIO, AVCC, reference and mode strap | Serial mode confirmed to the chip, VIO 3.23–3.43 V (project target), AVCC 4.75–5.25 V; reference matches its selected mode; BUSY/DOUT never exceed the ESP32 input limit | Follow [module qualification](module-qualification.md); stop if strap identity or supply routing differs |
| 3b | ADC signal wires, inputs at known DC | `diagnostic-adc`; scope CONVST/BUSY/CS/SCLK/DOUTA using the probe table; voltages 1 V on V1 and 2 V on V2 | CVA/CVB share GPIO11 through DIST1 a29/b29/c29; 125 µs nominal trigger interval ±1%, 8 kHz ±0.1% averaged over 60 s of acquisition; scope and log jitter, nominal 1 µs high pulse (at least 25 ns), BUSY normally within the 4.2 µs datasheet limit; 128 serial clocks at 8 MHz, mode 2 idle HIGH / falling-edge sample through DB7/DOUTA; codes approximately 6554 / 13107, swapped voltages swap channels; error within ±65 codes plus measured source/meter uncertainty; exclude RESET-time discarded reads; no FAIL output | Wrong order/scale: check range, DOUTA, mode and grounds. Missing edges: check CVA/CVB/BUSY. Late-read error: inspect scope and firmware load |
| 4 | First complete analog path | Generator 1.5 V bias + 100 mVpp sine; probe RAW and ADC input | 20, 100, 500 and 1000 Hz ADC gains (4000 Hz on the scope only; it is the 8 kHz Nyquist frequency) within simulated tolerance envelope plus instrument uncertainty; 500 Hz nominal about −1.85 dB. Unplugged input settles near midpoint. Never drive below 0 or above 3 V in this test | Check both 3.3 kΩ and 47 nF stages, buffer orientation, supply and ground. Do not mistake bias voltage for muscle activity |
| 5 | Second analog path | Repeat step 4; drive one input while holding the other at midpoint | Exactly BB1/BB2 and EMG1/2; both identities correct and share one frame timestamp; no swapped inputs or clipping in intended signal range. Save noise and crosstalk measurements; set study-specific limits before claiming research suitability | Separate cables, inspect common impedance and analog supply; repeat with Wi-Fi disabled |
| 6 | Foot carrier, then shank carrier | `diagnostic-imu-one`, then `diagnostic-imu-two`; scope both INT1 lines | WHO_AM_I/readback pass; both FIFO counts and interrupt counts advance about 200/s; at rest one axis near ±1 g, remaining axes near 0 g; no overflow or missing-interrupt failure | Verify SPI jumpers, GPIO4 MOSI / GPIO5 MISO / GPIO6 SCLK, foot CS/INT1 GPIO7/16 and shank GPIO15/17, 3.3 V and orientation. Preserve raw counter wraps, IRQ anchors and both read times; host timestamps are estimates and startup counts can differ. First-interrupt grace is 100 ms; it is not permission for a missing wire |
| 7 | SD adapter/card | `breadboard-sd-only-2ch`; record synthetic inputs, convert file | A 60-minute run has no unexplained counter gaps, container CRC32 errors or queue faults; metadata names two inputs and unity RAW scaling; check END and stop reason. Blank ADC CRC/status columns are intentional. Full-card and power-cut tests report errors or recover only verified records | Check GPIO47 CMD, GPIO39 CLK, GPIO40 D0, all five adapter contacts, pull-ups and card supply |
| 8 | Wi-Fi enabled | `breadboard-record-2ch`; read the per-device Wi-Fi password once from the USB console at the bench, then run the laptop viewer while SD continues | Only EMG1/2 shown; lost Wi-Fi packets visible; original SD file passes independent counter/CRC checks. Save and compare both archives | Wireless gaps are not SD gaps; compare both logs. Reduce preview load only after identifying the bottleneck |
| 9 | Protected battery | Repeat full load, unplug all mains/USB; log supply and runtime | At least two hours measured runtime; 20 repeatable starts/stops; safe pack cutoff and no hot components | Record actual current, temperature and low-battery events; simulator power estimates cannot replace this |
| 10 | Bare MyoWare sensors and mounting | First test sensors electrically with no person attached; then follow institutional supervised protocol | Clearance, retention, cable strain and artifacts checked; required consent/safety review complete | Return to the last passing stage. Never attach a person while using lab instruments, charging, USB or mains-connected cables |

For steps 3–6, diagnostic acquisition runs in approximately one-second windows and stops ADC triggering before printing. **The spaces between diagnostic windows are intentional.** Use the recording builds for continuous capture and endurance tests. The firmware’s 80 µs BUSY wait is a fault deadline, not acceptable normal conversion time. AD7606 has no external clock or separate DRDY output; shared net name ADC_DRDY means BUSY here.

Use `record-2ch` only on the custom PCB (SD CMD GPIO38). It is not interchangeable with the breadboard image. Flash all three files at the addresses in the chosen manifest.

## Reading the diagnostic serial lines

The first line names the firmware, for example `firmware=ad7606-2ch-1.8 stage=3 hardware=breadboard channels=2`; record it with the binary hash. Each acquisition window then prints one `ADC` line, and stage-6 images add one `IMU` line per sensor.

| Field | Meaning | How to use it |
|---|---|---|
| `elapsed_us`, `edges`, `good` | Window length, BUSY falling edges and frames read | Rate = `good` × 1,000,000 / `elapsed_us`; expect about 8,000 per second. Windows pause between prints, so use a logic-analyzer capture for the 125 µs interval gate |
| `chN_mean` | Mean signed code | Volts at the ADC input = code × 5 / 32768. Ideal 1.000 V = 6,553.6 codes and 2.000 V = 13,107.2; compute from the measured source |
| `min`, `max` | Extreme codes in the window | Clipping or spikes; −32,768 or 32,767 means the input range was exceeded |
| `rms_ac_codes` | RMS of the code minus its mean | For a sine, peak-to-peak volts ≈ `rms_ac_codes` × 2.828 × 152.588 µV. With a DC-held input it is broadband noise up to 4 kHz in codes |
| `interval_us`, `packets`, `interrupts` (IMU) | Host time covered by the IMU counts, FIFO packets and INT1 edges | Rate = `packets` × 1,000,000 / `interval_us`; expect about 200 per second per sensor, with `interrupts` close to `packets` |
| `ax_raw`…`gz_raw` (IMU) | Last packet's raw axes | ±16 g: 2,048 counts per g. ±2000 °/s: 16.384 counts per °/s |
| `tick_step_mean`, `host_us_per_tick` (IMU) | Mean FIFO timestamp step and ESP32 µs per sensor tick | Expect about 4,687.5 and 1.067: ICM-42688 "1 µs" ticks last 32/30 µs. Average over at least 60 windows for the stage-6 check |

Nominal stage-4 values for a 100 mVpp sine at unity DC gain, from the two ideal 1,026 Hz poles only (the simulated tolerance envelope remains the acceptance reference):

| Frequency | Nominal gain | Expected `rms_ac_codes` |
|---|---|---|
| 20 Hz | −0.00 dB | 231.6 |
| 100 Hz | −0.08 dB | 229.5 |
| 500 Hz | −1.85 dB | 187.2 |
| 1000 Hz | −5.80 dB | 118.8 |

Compute the gain from your measured input amplitude, not the generator display. A one-second window holds a whole number of cycles only for some frequencies; average several windows.

## Results sheet

Copy one row per test; include failures and retests. Do not prefill these with simulator output.

| Date / operator | Stage / firmware SHA-256 | Module serial or photo | Instrument / calibration | Applied stimulus / load | Measured value | Limit / uncertainty | Pass/fail / notes |
|---|---|---|---|---|---|---|---|
| | | | | | | | |

After all laboratory stages, the final PCB still needs power startup, switching ripple, antenna/USB, thermal, noise, crosstalk and sustained recording checks. Breadboards validate the logical signal path, not the final board layout.

Each ADC configuration clocks a discarded read during RESET to configure the controller clock before measurement. Expect normally one at diagnostic initialization, and two before the first recording session after boot (boot plus session configuration). No measurement trigger or counted sample occurs during those reads; identify them separately on the scope. Confirm the received module’s serial strap independently and verify physical mode-2 idle clock. The first counted conversion must have the expected DC codes. A diagnostic failure latches and requires reset/restart after correcting the cause.

## Stopping and checking a recording

For stages 7–9, wait for the recording LED to turn off before removing power or the SD card. An error LED, a nonzero wireless stop reason or a missing END packet requires investigation; do not label the trial successful from a visible filename. Convert the original SD file and keep its quality report with the measured results. A decoded END cannot certify persistence after a final sync/close error. See the [stop reasons and recovery checks](recording-verification.html). The recording images carry firmware identity `ad7606-2ch-1.6`. All seven current v1.6 laboratory profiles were recompiled; the current diagnostic images have not been rerun in Wokwi. Preserve each measured run’s actual binary hash rather than substituting a simulator result.
