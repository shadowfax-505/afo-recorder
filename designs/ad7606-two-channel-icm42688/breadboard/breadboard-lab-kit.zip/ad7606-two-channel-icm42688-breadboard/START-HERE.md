# AD7606 two-channel breadboard lab kit

Project lead: Muttakin Rahman

Use this kit for exactly two MyoWare RAW inputs and two ICM-42688-P carriers.
Circuit routing remains revision 12; instructions apply the v1.6 simulation findings.
No physical measurement has been completed or certified.

1. Open a terminal in this extracted folder and run:
   python3 -m http.server 8769 --bind 127.0.0.1
2. Open http://127.0.0.1:8769/viewer/build.html?stage=1
   Read docs/breadboard-refinements.html and docs/lab-quickstart.html.
3. Work through the stages with power off between additions. Use the exact hole
   tables and breadboard/probe-connections.csv; fill docs/bench-checklist.csv with
   real readings and evidence. All supplied outcomes are NOT TESTED.
4. Flash one of the six included firmware/builds profiles, using all three files
   and the offsets from its manifest. Keep the actual application hash with the trial.
   Breadboard SDMMC is CMD GPIO47 / CLK GPIO39 / D0 GPIO40.
5. Convert an untouched SD copy with:
   python3 host/convert.py trial.afolog --out trial-converted
   Audit the original SD file and laptop archive separately.

Included firmware uses source set ad7606-2ch-1.6 and ESP-IDF v5.4.2. It has been
cross-compiled, not flashed to an assembled recorder. The canonical validation
file describes seven compiled profiles; this archive intentionally includes only
the six breadboard profiles. The PCB recording binary and Wokwi simulation-only
images are excluded. Do not flash an instrumented simulator image to hardware.

The viewer uses local assets and an HTTP server. Offline guides and wire tables
are included. Evidence/manufacturing links outside this kit open the published
project; those links were rewritten in packaged HTML only. Complete KiCad and
historical simulation evidence remain in the main project repository.

Check the received AD7606 board's supplies, logic levels, internal reference and
serial straps BEFORE adding ESP32 signal leads. Follow module qualification.
Use synthetic signals only with instruments/USB attached; no person connected.
Read the included source notices and keep them with any redistributed models.
