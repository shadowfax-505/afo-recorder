#pragma once
#include "variant.h"
#define ADC_CONVST 11

// Revision B ESP32-S3-WROOM-1-N8R8. Onboard LEDs, active high.
#define ADC_DRDY 8
#define ADC_RESET 9
#define USB_PRESENT_PIN 21
#ifndef EMG_CHANNEL_COUNT
#define EMG_CHANNEL_COUNT 2
#endif
#if EMG_CHANNEL_COUNT != 2
#error "This hardware has exactly two EMG inputs"
#endif
#define ADS_CLOCK_REG ((EMG_CHANNEL_COUNT == 2 ? 0x0300 : 0x0f00) | 0x000a)
#define ADS_MODE_REG 0x0111
#define ADC_SCK 12
#define ADC_MISO 13
#if !AFO_AD7606
#define ADC_MOSI 11 // ADS131M04 builds only. AD7606 leaves MOSI unconnected; GPIO11 is CONVST.
#endif
#define ADC_CS 10
#define IMU_SCK 6
#define IMU_MISO 5
#define IMU_MOSI 4
#define FOOT_CS 7
#define SHANK_CS 15
#define FOOT_INT 16
#define SHANK_INT 17
#define SD_CLK 39
#ifndef AFO_BREADBOARD
#define AFO_BREADBOARD 0
#endif
#if AFO_BREADBOARD
#define SD_CMD 47
#define AFO_SD_METADATA "\"sd_cmd_gpio\":47,\"sd_clk_gpio\":39,\"sd_d0_gpio\":40,"
#else
#define SD_CMD 38
#define AFO_SD_METADATA "\"sd_cmd_gpio\":38,\"sd_clk_gpio\":39,\"sd_d0_gpio\":40,"
#endif
#define SD_D0 40
// AD7606 STBY (pin 7). On the PCB, AVCC (5V_ADC) is generated from 3V3D, so
// VDRIVE rises first. A 100 k pull-down holds STBY low; with RANGE low that
// is full shutdown (ADI AN-1091) until the firmware releases it. The
// breadboard ADC module keeps its own STBY tie, so it has no STBY GPIO.
#if AFO_BREADBOARD
#define ADC_STBY -1
#else
#define ADC_STBY 14
#endif
#define ADC_WAKE_MS 30 // Rev. G Table 3 tWAKE-UP SHUTDOWN, internal reference (max).
#define BUTTON_PIN 18
#define LED_RECORD 41
#define LED_ERROR 42
#define LED_BATTERY 2
#define BATTERY_PIN 1  // ADC1 channel 0; 100k/100k divider from protected 1S pack.
#define EMG_HZ 8000
#define IMU_HZ 200
#ifndef IMU_COUNT
#define IMU_COUNT 2
#endif
#define ENABLE_IMUS (IMU_COUNT > 0)
#ifndef HARDWARE_VARIANT
#define HARDWARE_VARIANT "pcb"
#endif
#define ADC_REFERENCE_MV (AFO_AD7606 ? 5000 : 1200) // Nominal signed full-scale, not measured.
#define ADC_REFERENCE_MEASURED 0 // Set to 1 only after measuring and entering the rail voltage.
#define BATTERY_DIVIDER 2.0f
#define BATTERY_WARN_MV 3500
#define BATTERY_STOP_MV 3300
#define MIN_FREE_BYTES (64ULL * 1024 * 1024)
#define MAX_SESSION_US (2ULL * 60 * 60 * 1000000)
// 20,480 x 64-byte records in PSRAM: about 2.44 s at 8,000 EMG + 400 IMU records/s.
// The SD specification permits write-busy periods up to 250 ms (SDHC) or
// 500 ms (SDXC); the older 2,048-entry internal queue held only 0.244 s.
#define RECORD_QUEUE_LENGTH 20480
#define SD_MOUNT "/sdcard"

#define AFO_FIRMWARE_ID "ad7606-2ch-1.11"

// Laptop preview uses a private WPA2 access point. No password is compiled in:
// each recorder generates a random one on first boot, keeps it in NVS and
// prints it on the USB console at every boot. Erasing flash creates a new one.
#ifndef ENABLE_WIFI_LIVE
#define ENABLE_WIFI_LIVE 1
#endif
#define WIFI_LIVE_SSID "AFO-Recorder-B"
#define WIFI_LIVE_PASSWORD_CHARS 16
#define WIFI_LIVE_PORT 3333
// Largest metadata JSON sent to the laptop; host/live_protocol.py MAX_PAYLOAD
// must match. 1,400 + 32 framing bytes stays inside one 1,500-byte Wi-Fi MTU.
#define WIFI_LIVE_METADATA_MAX 1400
