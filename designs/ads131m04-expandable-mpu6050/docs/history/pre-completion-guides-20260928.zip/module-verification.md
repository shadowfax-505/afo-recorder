> MPU variant: [mpu6050-wiring-and-timing.md](mpu6050-wiring-and-timing.md) is authoritative for sensor wiring, timing and current release gates. Inherited ADC/analog instructions remain applicable.

# Module verification and procurement gate

Lab ADC: **ADS131M04 evaluation/breakout board (exact board not selected; availability dependent)**. Module dimensions, physical header numbering and jumper positions are unverified. No physical ADC-module wiring diagram is released. Breadboard diagrams identify functional terminals only. A seller function list and a top-side product photograph do not establish continuity or jumper configuration. Do not interpret `Vx` in the photo as VIO without tracing it.

Before connecting ESP32 signal wires:
1. Obtain the actual board, inspect both faces and record board revision and chip marking. Obtain its schematic or trace powered-off continuity to the ADC pins. Record a numbered connector photograph with pin-1 orientation.
2. Identify supply/GND, interface supply, serial-mode straps and output-data path. Confirm onboard straps or buffers do not force conflicting levels. Measure resistance first; never strap an unknown header pin to a rail.
3. Apply a current-limited supply with ESP32 disconnected. Measure interface supply and BUSY/data output levels using an oscilloscope. For 3.3 V GPIO, require normal lows <0.4 V and highs 2.6–3.45 V with no excursions below −0.3 V or above 3.6 V. Investigate overshoot before connection. These are project interface checks, not permission to operate at absolute limits.
4. Sign the verification table, then produce the board-specific header map. Until then, the stage-3 lab build remains blocked at wiring release.

Ready-made IMUs: two RoboticsBD GY-521/MPU-6050 modules. Follow [mpu6050-wiring-and-timing.md](mpu6050-wiring-and-timing.md) for I²C, addresses, interrupts, pull-up and power checks. Physical header order remains unverified.

Controller: ESP32-S3 development board with the **N8R8** module and all required pins exposed. Its regulator, USB path and buttons differ from the custom PCB. Verify GPIO19/20 native USB and GPIO35–37 PSRAM restrictions; use the specified GPIO map. The PCB's USB presence interlock and battery sense circuitry must be reproduced on the fixture; the development board USB connector alone does not implement them.

Lab analog: five MCP6002-I/P DIP8 dual amplifiers (four signal boards plus midpoint), 1% resistors, filter capacitors verified within ±10%, 100 nF bypass per IC, and four BAV199 on technician-assembled SOT-23 carriers. Carrier chip-pad labels are not carrier header numbers. PCB uses MCP6004 quads and MCP6001 midpoint; same family/transfer function, different package and parasitics. Verify pinout and stability on the lab fixture.

Lab power may initially use isolated, current-limited laboratory rails. This is a **test-fixture difference**: it does not validate the final TPS63070, TPS7A2030, reverse-battery protection or ADC clock supply. Their final implementation requires separate power/loop review and physical checks. Solderless breadboards are unsuitable for reproducing fast switching loops. No extra custom test PCB is required or included.

| Function | ESP32 GPIO / required state | Verified physical module pin | Evidence / reviewer |
|---|---|---|---|
| Ground | GND | PENDING | |
| ADC supply | 3.0 V analog / 3.3 V digital, subject to module schematic | PENDING | |
| Digital interface supply | 3.3 V | PENDING | |
| Clock / serial SCLK | GPIO12 | PENDING | |
| Serial data output | GPIO13 | PENDING | |
| Chip select | GPIO10 | PENDING | |
| MOSI / DIN | GPIO11 | PENDING | |
| DRDY | GPIO8 | PENDING | |
| Reset | GPIO9 | PENDING | |

Use the selected module's supported 8.192 MHz clock path. Disable conflicting onboard clock drivers before applying any external clock. Firmware uses OSR512/high-resolution mode and sensor-frame CRC. Source: [TI ADS131M04 datasheet](https://www.ti.com/lit/ds/symlink/ads131m04.pdf).
