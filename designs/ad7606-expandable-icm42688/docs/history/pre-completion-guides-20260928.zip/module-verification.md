# Module verification and procurement gate

Lab ADC: **RoboticsBD RBD-3184, photo marked HW-AD7606-F4 with AD7606BSTZ**. Module dimensions, physical header numbering and jumper positions are unverified. No physical ADC-module wiring diagram is released. Breadboard diagrams identify functional terminals only. A seller function list and a top-side product photograph do not establish continuity or jumper configuration. Do not interpret `Vx` in the photo as VIO without tracing it.

Before connecting ESP32 signal wires:
1. Obtain the actual board, inspect both faces and record board revision and chip marking. Obtain its schematic or trace powered-off continuity to the ADC pins. Record a numbered connector photograph with pin-1 orientation.
2. Identify supply/GND, interface supply, serial-mode straps and output-data path. Confirm onboard straps or buffers do not force conflicting levels. Measure resistance first; never strap an unknown header pin to a rail.
3. Apply a current-limited supply with ESP32 disconnected. Measure interface supply and BUSY/data output levels using an oscilloscope. For 3.3 V GPIO, require normal lows <0.4 V and highs 2.6–3.45 V with no excursions below −0.3 V or above 3.6 V. Investigate overshoot before connection. These are project interface checks, not permission to operate at absolute limits.
4. Sign the verification table, then produce the board-specific header map. Until then, the stage-3 lab build remains blocked at wiring release.

Ready-made IMUs: select two identical ICM-42688-P boards exposing SPI and interrupts and accepting 3.3 V. Their exact SKU, pin order, axis orientation and onboard pull-ups/regulator are also pending verification. Use GPIO4 MOSI,5 MISO,6 SCLK,7 foot-CS,15 shank-CS,16 foot-INT,17 shank-INT. Do not assume a connector order from these GPIO numbers.

Controller: ESP32-S3 development board with the **N8R8** module and all required pins exposed. Its regulator, USB path and buttons differ from the custom PCB. Verify GPIO19/20 native USB and GPIO35–37 PSRAM restrictions; use the specified GPIO map. The PCB's USB presence interlock and battery sense circuitry must be reproduced on the fixture; the development board USB connector alone does not implement them.

Lab analog: five MCP6002-I/P DIP8 dual amplifiers (four signal boards plus midpoint), 1% resistors, filter capacitors verified within ±10%, 100 nF bypass per IC, and four BAV199 on technician-assembled SOT-23 carriers. Carrier chip-pad labels are not carrier header numbers. PCB uses MCP6004 quads and MCP6001 midpoint; same family/transfer function, different package and parasitics. Verify pinout and stability on the lab fixture.

Lab power may initially use isolated, current-limited laboratory rails. This is a **test-fixture difference**: it does not validate the final TPS63070, TPS7A2030, reverse-battery protection or TPS60150 5 V charge pump. Their final implementation requires separate power/loop review and physical checks. Solderless breadboards are unsuitable for reproducing fast switching loops. No extra custom test PCB is required or included.

| Function | ESP32 GPIO / required state | Verified physical module pin | Evidence / reviewer |
|---|---|---|---|
| Ground | GND | PENDING | |
| ADC supply | regulated 5 V, ADC AVCC 4.75–5.25 V | PENDING | |
| Digital interface supply | 3.3 V | PENDING | |
| Clock / serial SCLK | GPIO12 | PENDING | |
| Serial data output | GPIO13 | PENDING | |
| Chip select | GPIO10 | PENDING | |
| CONVSTA + CONVSTB | GPIO11 | PENDING | |
| BUSY | GPIO8 | PENDING | |
| Reset | GPIO9 | PENDING | |

For the bare AD7606 chip, serial DOUTA is pin24; PAR/SER pin6 high; DB15/BYTE SEL pin33 low; OS0/1/2 pins3/4/5 low; RANGE pin8 low (±5 V); STBY pin7 high; REFSELECT pin34 high for internal reference. CONVSTA/B pins9/10 share a trigger. **These are IC pin numbers, not module header numbers.** Inspect module straps before making any changes. Read all eight words through DOUTA; V5–V8 are grounded and disabled EMG inputs are never exported as muscle data. No AD7606 sensor-frame CRC exists; file/packet integrity checks cannot detect every ADC serial bit error.

Source: [ADI AD7606 Rev G datasheet](https://www.analog.com/media/en/technical-documentation/data-sheets/ad7606_7606-6_7606-4.pdf). Supplier listing: [RoboticsBD RBD-3184](https://store.roboticsbd.com/analog-digital-module/3184-16-bit-adc-8-channel-synchronization-ad7606-data-acquisition-module-200ksps-robotics-bangladesh.html). Board photograph is identification evidence only.
